import os
import random

ART_STYLES = {
    "Classic Poser / Daz 3D (2000s)": (
        "Classic 2000s Poser 3D character render, DAZ 3D software aesthetic, "
        "retro CGI digital figure model, smooth slightly waxy specular skin, raytraced digital render, "
        "studio three-point lighting, nostalgic early 2000s computer graphics character portrait, "
        "not photorealistic, not high definition pores, no blemishes, no scars, isolated on a solid pure black background"
    ),
    "Mid-2000s Game Engine (Xbox 360 / PS3 Era)": (
        "Mid-2000s 3D video game character render, Xbox 360 and PS3 era fighting game model, "
        "style of Virtua Fighter 5 and UFC 2009 Undisputed, slightly dated 3D character model, "
        "solid specular skin shading without micro-pores or hyper-realism, clean studio rim lighting, "
        "not photorealistic, not ultra-high definition, no blemishes, no scars, isolated on a solid pure black background"
    ),
    "Early 2000s Pre-Rendered CGI Cutscene": (
        "Early 2000s pre-rendered CGI video game cutscene character, classic 3ds Max raytraced CGI portrait, "
        "smooth digital mesh, soft raytraced shadows, nostalgic PC game CGI character render, "
        "not photorealistic, no micro skin texture, no blemishes, no scars, isolated on a solid pure black background"
    ),
    "Arcade 3D Fighter (Tekken 5 / Soulcalibur III)": (
        "Mid-2000s arcade fighting game 3D character select render, in the style of Tekken 5 and Soulcalibur III, "
        "stylized semi-realistic 3D character model, crisp polygonal definition, bold dramatic studio lighting, "
        "smooth clean skin, not photorealistic, no skin pores, no blemishes, no scars, isolated on a solid pure black background"
    ),
    "Modern Stylized 3D (Street Fighter 6 / Tekken 8)": (
        "High-end 3D video game character render in the style of Street Fighter 6 and Tekken 8, "
        "detailed Unreal Engine 5 stylized 3D character asset, crisp studio rim lighting, "
        "clean smooth skin, no skin pores, no blemishes, no scars, isolated on a solid pure black background"
    )
}

ETHNICITY_DATA = {
    "Caucasian White": ("Wh", "Caucasian White", [
        "jet black", "dark brown", "chestnut brown", "medium brown",
        "dirty blonde", "golden blonde", "sandy blonde", "ash blonde", "auburn", "ginger red"
    ]),
    "Black African-descent": ("Bl", "Black African-descent", ["jet black", "dark brown"]),
    "East Asian": ("As", "East Asian", ["jet black", "dark brown"]),
    "Hispanic Latino": ("Hi", "Hispanic Latino", ["jet black", "dark brown"]),
    "Middle Eastern Arab": ("ME", "Middle Eastern Arab", ["jet black", "dark brown"]),
    "South Asian Indian": ("SA", "South Asian Indian", ["jet black", "dark brown"])
}

WEIGHT_DATA = {
    "Flyweight (Women / Small)": ("FL", "compact slender frame, agile athletic build, lightweight bone structure"),
    "Lightweight": ("LW", "lean narrow lightweight frame with a slim waist"),
    "Middleweight": ("MW", "medium athletic middleweight frame with a balanced shoulder-to-waist ratio"),
    "Heavyweight": ("HW", "massive wide heavyweight frame with a thick barrel chest and heavy bone structure")
}

HEIGHT_DATA = {
    "Short": ("Sh", "slightly high-angle camera looking down, compact short torso, stocky proportions"),
    "Average": ("Av", "eye-level straight-on camera angle, standard balanced anatomical proportions"),
    "Tall": ("Ta", "slightly low-angle camera looking up, elongated lanky torso, long neck and long reach")
}

STYLE_DATA = {
    # Authentic Kung Fu Poses (Vivid, no fists forward)
    "Kung Fu (Shaolin Open Palm)": (
        "KF",
        "traditional Shaolin Kung Fu stance with open hands, lead hand an open flat palm facing forward with fingers pointing upward and thumb tucked, rear hand an open palm resting near the chest, fluid Chinese martial arts posture, open hands, no closed fists"
    ),
    "Kung Fu (Tiger Claw)": (
        "KF",
        "traditional Kung Fu tiger claw stance, both hands shaped into curved open tiger claws with tensed spread fingers, lead claw extended forward at eye level, rear claw coiled near the jaw, dynamic Chinese martial arts pose, no clenched fists"
    ),
    "Kung Fu (Fist-to-Palm Salute)": (
        "KF",
        "traditional Kung Fu martial arts salute, right clenched fist pressed firmly against the flat open left palm in front of the chest, upright respectful Bai Shi martial artist posture"
    ),
    "Kung Fu (Crane Stance)": (
        "KF",
        "classic Shaolin crane stance, lead hand an open knife-hand extended forward at shoulder height, rear arm arched gracefully with fingers pinched into an open crane beak, fluid traditional Wushu martial artist posture, no closed fists"
    ),

    # Combat Poses
    "Boxing (Orthodox)": ("Box", "classic orthodox boxing stance with lead left hand extended forward and right hand by the cheek"),
    "Boxing (Peek-a-Boo)": ("Box", "tight high peek-a-boo boxing guard with both gloved fists protecting the chin and elbows tucked"),
    "Boxing (Philly Shell)": ("Box", "Philly shell boxing shoulder-roll stance with lead shoulder raised and rear hand guarding the jaw"),
    "Wrestling (Collar Tie)": ("Wre", "crouched freestyle wrestling stance with both hands reaching forward for a collar tie"),
    "Wrestling (Takedown Shoot)": ("Wre", "low hunched takedown-ready wrestling posture with arms coiled to shoot"),
    "Muay Thai (High Guard)": ("MT", "traditional Muay Thai high guard with both open palms facing outward at forehead level"),
    "Muay Thai (Plum Clinch)": ("MT", "aggressive Muay Thai plum clinch posture with both hands reaching forward to cup the neck"),
    "Kickboxing (Dutch Guard)": ("KB", "dynamic Dutch kickboxing high guard with shoulders angled and fists raised by the temples"),
    "Jiu-Jitsu (Open Guard)": ("BJJ", "relaxed open-palm Brazilian Jiu-Jitsu grappling guard with fingers spread"),
    "Catch Wrestling (Claw)": ("Grp", "powerful catch-wrestling posture with hands outstretched to grab a wrist"),
    "Karate (Bladed Point Guard)": ("Kar", "side-on traditional Karate point-fighting stance with lead hand extended and rear hand chambered at the hip"),

    # Non-Fighting Poses (Tagged as Gen by default so any style in WMMA6 can use them)
    "Pose: Arms Crossed": ("Gen", "confident fighter portrait pose with arms firmly crossed over the chest, biceps flexed, relaxed dominant posture, shoulders back"),
    "Pose: Hands on Hips": ("Gen", "confident upright fighter stance with both hands resting firmly on the hips, chest pushed out, elbows flared wide, strong dominant athletic posture"),
    "Pose: Pointing at Camera": ("Gen", "dynamic charismatic fighter pose with one arm extended forward pointing directly at the camera with the index finger, other arm held at waist level, confident challenging expression"),
    "Pose: One Hand Number One (#1)": ("Gen", "confident athletic victory pose holding up one hand with the index finger raised displaying the number one sign ('we are number one'), other arm relaxed by the side, proud triumphant expression"),
    "Pose: One Hand V for Victory": ("Gen", "athletic pose holding up one hand in a classic two-finger V-sign for victory, two fingers raised in a peace sign gesture, other arm relaxed by the side, confident champion posture"),
    "Pose: One Fist Up by Face": ("Gen", "intense fighter portrait pose with one clenched gloved fist raised vertically next to the side of the cheek and jaw, elbow tucked in, other arm relaxed by the waist, fierce determined look"),
    "Pose: Hands Praying (Wai / Respect)": ("Gen", "respectful traditional martial arts prayer gesture with both flat palms pressed together in front of the chest and chin, fingers pointing upward in a reverent Wai prayer salute, elbows tucked"),
    "Pose: Meditation / Yoga Mudra": ("Gen", "composed martial artist in a calm meditation posture, hands held in front of the solar plexus in a classic yoga Gyan mudra, thumbs and index fingers lightly touching to form a circle with remaining fingers relaxed, dropped shoulders, serene centered zen focus")
}

STYLE_TAG_OVERRIDE = {
    "Auto (From Pose)": None,
    "Generic / All Styles (Gen)": "Gen",
    "Boxing (Box)": "Box",
    "Wrestling (Wre)": "Wre",
    "Muay Thai (MT)": "MT",
    "Kickboxing (KB)": "KB",
    "Jiu-Jitsu (BJJ)": "BJJ",
    "Catch Wrestling (Grp)": "Grp",
    "Karate (Kar)": "Kar",
    "Kung Fu (KF)": "KF"
}

PHYSIQUE_DATA = {
    "LCLS": "out of shape high body fat, soft protruding flabby belly, love handles, flat chest and thin soft arms with zero muscle definition",
    "LCAS": "soft dad-bod brawler physique, layer of belly fat and love handles over a solid average frame with normal-sized arms and shoulders",
    "LCHS": "powerlifter strongman build, massive thick muscles underneath a heavy layer of body fat, thick protruding gut and beefy arms",
    "ACLS": "normal healthy body fat percentage, smooth flat un-shredded torso, slender narrow frame with thin underdeveloped arms and flat chest",
    "ACAS": "standard natural athletic MMA fighter build, moderate muscle mass, healthy natural body fat percentage and solid core",
    "ACHS": "thickly muscled heavy-duty athlete build, massive broad chest, thick arms and traps with a normal natural body fat level and solid core",
    "HCLS": "extremely fit very low body fat, wiry lean sinewy frame, flat defined abs, thin skinny arms and flat chest",
    "HCAS": "lean well-conditioned athletic MMA build, low body fat with visible six-pack abs and serratus definition, paired with balanced normal-sized muscle mass",
    "HCHS": "extremely fit low body fat, deeply sculpted six-pack abs, heavily muscled bulging biceps and capped deltoids"
}

LOOKS_DATA_MALE = {
    "LL": ["unattractive asymmetrical face, wide flat nose and heavy brow ridge", "homely rugged face, bulbous nose, prominent ears and recessed chin"],
    "AL": ["average everyday masculine face, normal balanced facial proportions and square jaw", "standard rugged fighter face, broad cheekbones and neutral masculine features"],
    "HL": ["conventionally handsome symmetrical face, chiseled jawline and high cheekbones", "strikingly handsome model-like facial structure, sharp jawline and balanced proportions"]
}

LOOKS_DATA_FEMALE = {
    "LL": ["unattractive asymmetrical facial features, rugged athletic bone structure", "plain homely facial features with an uneven nose and prominent ears"],
    "AL": ["natural everyday athletic feminine facial structure, normal balanced features and defined jawline", "standard athletic woman fighter face, subtle cheekbones and determined jaw"],
    "HL": ["conventionally attractive symmetrical feminine face, sharp striking cheekbones and elegant athletic jawline", "strikingly beautiful athletic model-like facial structure with balanced proportions"]
}

MENACE_DATA = {
    "LM": ["warm approachable friendly smile, kind eyes and relaxed eyebrows", "cheerful confident grin, upbeat babyface fan-favorite demeanor"],
    "AM": ["calm neutral composed expression, relaxed focused eyes and normal professional athlete demeanor", "steady serious game-face, neutral closed mouth and attentive focused gaze"],
    "HM": ["cold emotionless deadpan predator stare, unblinking intense piercing eyes", "arrogant confident heel smirk, raised eyebrow and cocky prizefighter demeanor"]
}

HAIRSTYLES_MALE = [
    "completely shaved bald head", "closely cropped military buzzcut", "high-and-tight skin fade haircut",
    "messy medium-length tousled hair", "slicked-back hair", "long tied-back ponytail",
    "short curly crop haircut", "spiky fauxhawk haircut", "short textured crew cut",
    "modern undercut with textured top", "side-parted classic taper haircut", "wavy medium-length swept-back hair",
    "short tightly braided cornrows", "short dreadlocks pulled back", "flat-top military haircut",
    "tightly coiled short afro", "short spiky messy hair", "cropped buzzcut with a sharp hairline",
    "long hair tied back in a tight fighter bun", "low taper fade with curly top"
]

HAIRSTYLES_FEMALE = [
    "tightly braided fighter cornrows", "high athletic combat ponytail", "double dutch boxer braids",
    "slicked-back high fighter bun", "short sporty pixie cut", "undercut with braided side",
    "shoulder-length athletic bob haircut", "french braided pigtails", "messy top-knot athletic bun",
    "short textured crop haircut", "wavy shoulder-length swept-back hair", "tight high braided ponytail"
]

BEARDS_MALE = [
    "clean-shaven face", "clean-shaven face", "light five-o-clock shadow stubble",
    "heavy rugged stubble beard", "neatly trimmed short boxed beard", "thick full bushy beard",
    "chinstrap beard along the jawline", "classic circle beard goatee and mustache", "thick chevron mustache",
    "short goatee without mustache", "thin groomed mustache and chin patch", "pointed van dyke beard"
]

TATTOO_CHOICES = {
    "None (Clean Skin)": "no tattoos, completely clean smooth un-inked skin",
    "Subtle / Small": "subtle minimalist stylized fighter tattoo on the forearm or shoulder",
    "Single Arm Sleeve": "intricate stylized fighter tattoo sleeve covering one arm with clean bold lines",
    "Chest / Torso Piece": "bold artistic stylized fighter tattoo across the chest and collarbone",
    "Heavy / Inked": "extensive stylized fighting game character tattoos covering the chest, arms, and shoulders",
}

AGES = ["20-year-old young rookie", "24-year-old rising prospect", "28-year-old prime athletic", "32-year-old battle-tested veteran", "35-year-old seasoned veteran"]
COLORS = ["red", "royal blue", "black", "gold", "kelly green", "white", "charcoal grey", "navy blue", "crimson", "bright orange", "purple", "teal", "maroon", "forest green", "cobalt blue"]

class WMMAFighterPromptNode:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "gender": (["Female", "Male"],),
                "art_style": (list(ART_STYLES.keys()),),
                "ethnicity": (list(ETHNICITY_DATA.keys()),),
                "weight_class": (list(WEIGHT_DATA.keys()),),
                "height": (list(HEIGHT_DATA.keys()),),
                "pose": (list(STYLE_DATA.keys()),),
                "style_tag": (list(STYLE_TAG_OVERRIDE.keys()),),
                "tattoos": (["None (Clean Skin)", "Random (Weighted)", "Subtle / Small", "Single Arm Sleeve", "Chest / Torso Piece", "Heavy / Inked"],),
                "conditioning": (["Random (Weighted)", "Average (25-75)", "Low (<25)", "High (>75)"],),
                "strength": (["Random (Weighted)", "Average (25-75)", "Low (<25)", "High (>75)"],),
                "looks": (["Random (Weighted)", "Average (25-75)", "Handsome / Attractive (>75)", "Homely (<25)"],),
                "menace": (["Random (Weighted)", "Neutral Game-Face (25-75)", "Friendly Smile (<25)", "Intimidating Glare (>75)"],),
                "seed": ("INT", {"default": 0, "min": 0, "max": 0xffffffffffffffff}),
            }
        }

    RETURN_TYPES = ("STRING", "STRING")
    RETURN_NAMES = ("positive_prompt", "filename_prefix")
    FUNCTION = "generate"
    CATEGORY = "WMMA"

    def generate(self, gender, art_style, ethnicity, weight_class, height, pose, style_tag, tattoos, conditioning, strength, looks, menace, seed):
        rng = random.Random(seed)
        
        style_header = ART_STYLES.get(art_style, ART_STYLES["Classic Poser / Daz 3D (2000s)"])
        eth_code, eth_desc, hair_colors = ETHNICITY_DATA[ethnicity]
        wt_code, wt_desc = WEIGHT_DATA[weight_class]
        ht_code, ht_desc = HEIGHT_DATA[height]
        default_style_code, pose_desc = STYLE_DATA[pose]
        
        # Determine 5-part style code: Auto or manual override
        override_code = STYLE_TAG_OVERRIDE.get(style_tag)
        final_style_code = override_code if override_code else default_style_code
        
        # 1. Conditioning & Strength
        if conditioning == "Low (<25)":
            c_code = "LC"
        elif conditioning == "High (>75)":
            c_code = "HC"
        elif conditioning == "Average (25-75)":
            c_code = "AC"
        else:
            c_code = rng.choice(["LC", "AC", "AC", "HC"])
            
        if strength == "Low (<25)":
            s_code = "LS"
        elif strength == "High (>75)":
            s_code = "HS"
        elif strength == "Average (25-75)":
            s_code = "AS"
        else:
            s_code = rng.choice(["LS", "AS", "AS", "HS"])
            
        phy_code = f"{c_code}{s_code}"
        phy_desc = PHYSIQUE_DATA[phy_code]
        
        # 2. Looks & Menace
        if looks == "Homely (<25)":
            l_code = "LL"
        elif looks in ["Handsome / Attractive (>75)", "Handsome (>75)"]:
            l_code = "HL"
        elif looks == "Average (25-75)":
            l_code = "AL"
        else:
            l_code = rng.choice(["LL", "AL", "AL", "HL"])
            
        if menace == "Friendly Smile (<25)":
            m_code = "LM"
        elif menace == "Intimidating Glare (>75)":
            m_code = "HM"
        elif menace == "Neutral Game-Face (25-75)":
            m_code = "AM"
        else:
            m_code = rng.choice(["LM", "AM", "AM", "HM"])
            
        if gender == "Female":
            face_desc = rng.choice(LOOKS_DATA_FEMALE[l_code])
            h_style = rng.choice(HAIRSTYLES_FEMALE)
            f_hair = "clean-shaven smooth skin"
            pronoun_subj = "She"
            gender_word = "female"
        else:
            face_desc = rng.choice(LOOKS_DATA_MALE[l_code])
            h_style = rng.choice(HAIRSTYLES_MALE)
            f_hair = rng.choice(BEARDS_MALE)
            pronoun_subj = "He"
            gender_word = "male"
            
        expr_desc = rng.choice(MENACE_DATA[m_code])
        h_color = rng.choice(hair_colors)
        age_desc = rng.choice(AGES)
        shorts_col, gloves_col, top_col = rng.sample(COLORS, 3)
        
        # 3. Tattoos resolution
        if tattoos == "Random (Weighted)":
            tat_key = rng.choice([
                "None (Clean Skin)", "None (Clean Skin)", "None (Clean Skin)",
                "Subtle / Small", "Subtle / Small",
                "Single Arm Sleeve", "Chest / Torso Piece", "Heavy / Inked"
            ])
            tat_desc = TATTOO_CHOICES[tat_key]
        else:
            tat_desc = TATTOO_CHOICES.get(tattoos, TATTOO_CHOICES["None (Clean Skin)"])
        
        # 4. Hair phrase
        if gender == "Female":
            hair_phrase = f"{h_color} {h_style}"
        else:
            if "bald" in h_style:
                hair_phrase = f"a {h_style} and {h_color} {f_hair}" if "clean-shaven" not in f_hair else f"a {h_style} and {f_hair}"
            else:
                hair_phrase = f"{h_color} {h_style} and {f_hair}"

        # 5. Attire based on gender
        if gender == "Female":
            attire_phrase = (
                f"wearing a plain solid {top_col} athletic MMA sports bra compression top, "
                f"plain solid {shorts_col} MMA shorts visible at the bottom edge of the frame, "
                f"and plain solid {gloves_col} fingerless MMA gloves"
            )
        else:
            attire_phrase = (
                f"shirtless, wearing only plain solid {shorts_col} MMA shorts visible at the bottom edge of the frame "
                f"and plain solid {gloves_col} fingerless MMA gloves"
            )

        prompt = (
            f"{style_header}. "
            f"Waist-up medium portrait shot showing from the belt-line of the shorts to the top of the head, "
            f"{ht_desc}, looking directly at the camera. "
            f"A {age_desc} {eth_desc} {gender_word} MMA fighter with {hair_phrase}. "
            f"{pronoun_subj} has a {face_desc}, {tat_desc}, and displays a {expr_desc}. "
            f"{pronoun_subj} has a {wt_desc}, {phy_desc}. "
            f"{pronoun_subj} is in a {pose_desc}. "
            f"{pronoun_subj} is {attire_phrase}. Completely unbranded blank athletic gear, no text, no logos."
        )
        
        if gender == "Female":
            filename_prefix = f"F_{eth_code}_{wt_code}_{ht_code}_{final_style_code}_{phy_code}"
        else:
            filename_prefix = f"{eth_code}_{wt_code}_{ht_code}_{final_style_code}_{phy_code}"
            
        return (prompt, filename_prefix)

NODE_CLASS_MAPPINGS = {
    "WMMAFighterPromptNode": WMMAFighterPromptNode
}
NODE_DISPLAY_NAME_MAPPINGS = {
    "WMMAFighterPromptNode": "WMMA Fighter Prompt Builder"
}
